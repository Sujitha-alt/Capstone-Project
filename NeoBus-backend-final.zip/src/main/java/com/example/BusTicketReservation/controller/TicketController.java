package com.example.BusTicketReservation.controller;

import com.example.BusTicketReservation.entity.Booking;
import com.example.BusTicketReservation.service.TicketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/tickets")
public class TicketController {

    @Autowired
    private TicketService ticketService;

    // ✅ Get ticket details
    @GetMapping("/{id}")
    public ResponseEntity<Booking> getTicket(@PathVariable Long id) {
        Booking booking = ticketService.getBooking(id);
        return ResponseEntity.ok(booking);
    }

    // ✅ Cancel ticket
    @DeleteMapping("/{id}")
    public ResponseEntity<String> cancelTicket(@PathVariable Long id) {
        String message = ticketService.cancelBooking(id);
        return ResponseEntity.ok(message);
    }

    // ✅ Download ticket PDF
    @GetMapping("/{id}/pdf")
    public ResponseEntity<byte[]> downloadTicketPdf(@PathVariable Long id) throws Exception {
        return ticketService.downloadTicket(id);
    }
}
