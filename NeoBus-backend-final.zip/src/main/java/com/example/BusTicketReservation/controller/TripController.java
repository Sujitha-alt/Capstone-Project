package com.example.BusTicketReservation.controller;

import com.example.BusTicketReservation.entity.Trip;
import com.example.BusTicketReservation.service.TripService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/v1/trips")
@CrossOrigin
public class TripController {

    private final TripService tripService;

    public TripController(TripService tripService) {
        this.tripService = tripService;
    }

    // ✅ Add a trip (Admin)
    @PostMapping
    public Trip addTrip(@RequestBody Trip trip) {
        return tripService.addTrip(trip);
    }

    // ✅ Get all trips
    @GetMapping
    public List<Trip> getAllTrips() {
        return tripService.getAllTrips();
    }

    // ✅ Search trips by route + date
    @GetMapping("/search")
    public List<Trip> searchTrips(@RequestParam String source,
                                  @RequestParam String destination,
                                  @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date date) {
        return tripService.searchTrips(source, destination, date);
    }
}
