package com.example.BusTicketReservation.controller;

import com.example.BusTicketReservation.dto.BookingRequest;
import com.example.BusTicketReservation.dto.BookingResponse;
import com.example.BusTicketReservation.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    // Use DTOs for cleaner JSON input/output
    @PostMapping("/book")
    public BookingResponse bookTicket(@RequestBody BookingRequest request) {
        return bookingService.bookTicket(request);
    }
}
