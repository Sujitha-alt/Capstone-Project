package com.example.BusTicketReservation.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String busNumber;     // e.g. KA01AB1234
    private String busType;       // e.g. AC Sleeper
    private int totalSeats;
    private int availableSeats;   // ✅ New field
    private String route;
}
