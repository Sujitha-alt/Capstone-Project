package com.example.BusTicketReservation.repository;

import com.example.BusTicketReservation.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<Booking, Long> {}
