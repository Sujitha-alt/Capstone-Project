package com.example.BusTicketReservation.repository;

import com.example.BusTicketReservation.entity.Trip;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface TripRepository extends JpaRepository<Trip, Long> {
    List<Trip> findByRouteSourceAndRouteDestinationAndTripDate(
            String source, String destination, Date tripDate);
}
