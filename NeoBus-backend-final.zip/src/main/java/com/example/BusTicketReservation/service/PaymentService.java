package com.example.BusTicketReservation.service;

import com.example.BusTicketReservation.dto.PaymentRequest;
import com.example.BusTicketReservation.dto.PaymentResponse;
import com.example.BusTicketReservation.entity.Booking;
import com.example.BusTicketReservation.entity.Payment;
import com.example.BusTicketReservation.repository.BookingRepository;
import com.example.BusTicketReservation.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private BookingRepository bookingRepository;

    // ✅ Process payment
    public PaymentResponse processPayment(PaymentRequest request) {
        Booking booking = bookingRepository.findById(request.getBookingId())
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        // Validate amount
        if (booking.getTotalAmount() != request.getAmount()) {
            return new PaymentResponse(null, request.getAmount(), request.getPaymentMethod(), "FAILED");
        }

        // Save payment
        Payment payment = Payment.builder()
                .amount(request.getAmount())
                .paymentMethod(request.getPaymentMethod())
                .paymentDate(new Date())
                .status("SUCCESS")
                .booking(booking)
                .build();

        paymentRepository.save(payment);

        // ✅ Update booking status to PAID
        booking.setStatus("PAID");
        bookingRepository.save(booking);

        return new PaymentResponse(payment.getId(), payment.getAmount(), payment.getPaymentMethod(), "SUCCESS");
    }
}
