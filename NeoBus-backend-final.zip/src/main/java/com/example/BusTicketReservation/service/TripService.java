package com.example.BusTicketReservation.service;

import com.example.BusTicketReservation.entity.Trip;
import com.example.BusTicketReservation.repository.TripRepository;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class TripService {

    private final TripRepository tripRepository;

    public TripService(TripRepository tripRepository) {
        this.tripRepository = tripRepository;
    }

    public Trip addTrip(Trip trip) {
        return tripRepository.save(trip);
    }

    public List<Trip> getAllTrips() {
        return tripRepository.findAll();
    }

    public List<Trip> searchTrips(String source, String destination, Date tripDate) {
        return tripRepository.findByRouteSourceAndRouteDestinationAndTripDate(source, destination, tripDate);
    }
}
