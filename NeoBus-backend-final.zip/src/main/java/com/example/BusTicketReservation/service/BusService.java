package com.example.BusTicketReservation.service;

import com.example.BusTicketReservation.entity.Bus;
import com.example.BusTicketReservation.repository.BusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusService {

    @Autowired
    private BusRepository busRepository;

    public Bus addBus(Bus bus) {
        return busRepository.save(bus);
    }

    public List<Bus> getAllBuses() {
        return busRepository.findAll();
    }

    public Bus getBus(Long id) {
        return busRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Bus not found with id: " + id));
    }

    public String deleteBus(Long id) {
        busRepository.deleteById(id);
        return "Bus deleted successfully!";
    }
}
