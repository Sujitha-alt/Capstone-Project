package com.example.BusTicketReservation.service;

import com.example.BusTicketReservation.entity.Booking;
import com.example.BusTicketReservation.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.Optional;

// PDF dependencies (make sure you added iText in pom.xml)
// <dependency>
//   <groupId>com.itextpdf</groupId>
//   <artifactId>itextpdf</artifactId>
//   <version>5.5.13.3</version>
// </dependency>
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class TicketService {

    @Autowired
    private BookingRepository bookingRepository;

    // ✅ Get booking by ID
    public Booking getBooking(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found with id: " + id));
    }

    // ✅ Cancel booking by ID
    public String cancelBooking(Long id) {
        Optional<Booking> bookingOpt = bookingRepository.findById(id);
        if (bookingOpt.isEmpty()) {
            throw new RuntimeException("Booking not found with id: " + id);
        }
        Booking booking = bookingOpt.get();
        booking.setStatus("CANCELLED");
        bookingRepository.save(booking);
        return "Booking cancelled successfully!";
    }

    // ✅ Generate ticket as PDF bytes
    public byte[] generateTicketPdf(Booking booking) throws Exception {
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter.getInstance(document, out);

        document.open();
        document.add(new Paragraph("Bus Ticket Reservation System"));
        document.add(new Paragraph("Ticket Number: " + booking.getTicketNumber()));
        document.add(new Paragraph("Passenger: " + booking.getUser().getUsername()));
        document.add(new Paragraph("Trip: " + booking.getFromCity() + " -> " + booking.getToCity()));
        document.add(new Paragraph("Seats: " + booking.getSeats()));
        document.add(new Paragraph("Total Amount: " + booking.getTotalAmount()));
        document.add(new Paragraph("Status: " + booking.getStatus()));
        document.close();

        return out.toByteArray();
    }

    // ✅ Download PDF as HTTP response
    public ResponseEntity<byte[]> downloadTicket(Long id) throws Exception {
        Booking booking = getBooking(id);
        byte[] pdfBytes = generateTicketPdf(booking);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ticket-" + booking.getId() + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }
}
