package com.example.BusTicketReservation.service;

import com.example.BusTicketReservation.dto.BookingRequest;
import com.example.BusTicketReservation.dto.BookingResponse;
import com.example.BusTicketReservation.entity.Booking;
import com.example.BusTicketReservation.entity.Bus;
import com.example.BusTicketReservation.entity.User;
import com.example.BusTicketReservation.repository.BookingRepository;
import com.example.BusTicketReservation.repository.BusRepository;
import com.example.BusTicketReservation.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BusRepository busRepository;

    // ✅ Book a ticket
    public BookingResponse bookTicket(BookingRequest request) {
        // Check user
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Check bus
        Bus bus = busRepository.findById(request.getBusId())
                .orElseThrow(() -> new RuntimeException("Bus not found"));

        // ✅ Check seat availability
        if (bus.getAvailableSeats() < request.getSeats()) {
            throw new RuntimeException("Not enough seats available!");
        }

        // Price per seat = 100
        double totalAmount = request.getSeats() * 100.0;

        // Deduct available seats
        bus.setAvailableSeats(bus.getAvailableSeats() - request.getSeats());
        busRepository.save(bus);

        // Create booking
        Booking booking = Booking.builder()
                .ticketNumber("TICKET-" + UUID.randomUUID())
                .fromCity(request.getFromCity())
                .toCity(request.getToCity())
                .seats(request.getSeats())
                .bookingDate(new Date())
                .totalAmount(totalAmount)
                .status("CONFIRMED")
                .user(user)
                .bus(bus)
                .build();

        bookingRepository.save(booking);

        return new BookingResponse(
                booking.getId(),
                booking.getTicketNumber(),
                booking.getFromCity(),
                booking.getToCity(),
                booking.getSeats(),
                booking.getTotalAmount(),
                booking.getStatus(),
                bus.getBusNumber(),
                bus.getBusType(),
                bus.getAvailableSeats()
        );
    }

    // ✅ Cancel a booking
    public String cancelBooking(Long id) {
        Booking booking = bookingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        if ("CANCELLED".equalsIgnoreCase(booking.getStatus())) {
            return "Booking is already cancelled!";
        }

        booking.setStatus("CANCELLED");

        // Restore seats
        Bus bus = booking.getBus();
        bus.setAvailableSeats(bus.getAvailableSeats() + booking.getSeats());
        busRepository.save(bus);

        bookingRepository.save(booking);

        return "Booking cancelled successfully!";
    }
}
