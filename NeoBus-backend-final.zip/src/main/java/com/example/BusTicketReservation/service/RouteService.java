package com.example.BusTicketReservation.service;

import com.example.BusTicketReservation.entity.Route;
import com.example.BusTicketReservation.repository.RouteRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RouteService {

    private final RouteRepository routeRepository;

    public RouteService(RouteRepository routeRepository) {
        this.routeRepository = routeRepository;
    }

    // Get all routes
    public List<Route> getAllRoutes() {
        return routeRepository.findAll();
    }

    // Add new route
    public Route addRoute(Route route) {
        return routeRepository.save(route);
    }

    // Delete route
    public void deleteRoute(Long id) {
        routeRepository.deleteById(id);
    }
}
