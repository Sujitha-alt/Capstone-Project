# Sujitha — Redbus-style frontend (with confirmations + admin gating)

## Run
```bash
npm install
copy .env.example .env  # Windows
# edit VITE_API_BASE_URL to your Spring Boot URL
npm run dev
```

## Admin visibility
```sql
UPDATE users SET role = 'ADMIN' WHERE email = 'example@gmail.com';
-- If backend uses hasRole("ADMIN"), store ROLE_ADMIN instead:
-- UPDATE users SET role = 'ROLE_ADMIN' WHERE email = 'example@gmail.com';
```

## Confirmations
- Logout, seat selection → checkout, payment, booking cancellation
- Admin deletes for routes/trips/buses/operators/coupons
- Reports pages include PDF download buttons
