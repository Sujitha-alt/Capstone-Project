export function getToken(){ return localStorage.getItem("token"); }

function base64UrlDecode(str){
  try{
    const base64 = str.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((str.length + 3) % 4);
    return decodeURIComponent(atob(base64).split("").map(c => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2)).join(""));
  }catch{ return null; }
}

export function decodeJwt(token){
  if(!token) return null;
  const parts = token.split(".");
  if(parts.length !== 3) return null;
  const json = base64UrlDecode(parts[1]);
  try{ return JSON.parse(json); }catch{ return null; }
}

export function getRole(){
  const t = getToken();
  const payload = decodeJwt(t);
  const claim = payload?.role || payload?.authorities?.[0] || localStorage.getItem("role");
  return claim || null;
}
export function isAdmin(){ const r = getRole(); return r === "ROLE_ADMIN" || r === "ADMIN"; }
export function isLoggedIn(){ return !!(getToken() || localStorage.getItem("role")); }
