import React from "react";

export default function ConfirmDialog({
  show,
  title = "Confirm action",
  message = "Are you sure?",
  confirmText = "Confirm",
  cancelText = "Cancel",
  onConfirm = () => {},
  onCancel = () => {},
}){
  if(!show) return null;
  return (
    <div className="confirm-mask">
      <div className="confirm-card">
        <h5 className="mb-2">{title}</h5>
        <p className="text-muted">{message}</p>
        <div className="d-flex gap-2 justify-content-end pt-2">
          <button className="btn btn-outline-secondary" onClick={onCancel}>{cancelText}</button>
          <button className="btn btn-primary" onClick={onConfirm}>{confirmText}</button>
        </div>
      </div>
    </div>
  );
}
