import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { isAdmin, isLoggedIn } from "../utils/auth";
import ConfirmDialog from "./ConfirmDialog";

export default function Navbar(){
  const admin = isAdmin();
  const logged = isLoggedIn();
  const navigate = useNavigate();
  const [logoutAsk, setLogoutAsk] = useState(false);

  const doLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    setLogoutAsk(false);
    navigate("/login");
  };

  return (
    <header className="rb-nav">
      <nav className="container d-flex align-items-center justify-content-between py-2">
        <Link to={logged?"/search":"/"} className="rb-brand d-flex align-items-center">
          <span className="rb-brand-badge"></span> Sujitha
        </Link>
        <ul className="nav gap-2 mb-0 align-items-center">
          {logged && <li className="nav-item"><Link className="btn btn-link" to="/search">Buses</Link></li>}
          {logged && <li className="nav-item"><Link className="btn btn-link" to="/bookings">My Trips</Link></li>}
          <li className="nav-item"><Link className="btn btn-link" to="/offers">Offers</Link></li>
          <li className="nav-item"><Link className="btn btn-link" to="/support">Help</Link></li>

          {admin && (
            <li className="nav-item dropdown">
              <button className="btn btn-link dropdown-toggle" data-bs-toggle="dropdown">Admin</button>
              <ul className="dropdown-menu dropdown-menu-end">
                <li><Link className="dropdown-item" to="/admin/routes">Routes</Link></li>
                <li><Link className="dropdown-item" to="/admin/trips">Trips</Link></li>
                <li><Link className="dropdown-item" to="/admin/buses">Buses</Link></li>
                <li><Link className="dropdown-item" to="/admin/operators">Operators</Link></li>
                <li><Link className="dropdown-item" to="/admin/coupons">Coupons</Link></li>
                <li><Link className="dropdown-item" to="/admin/reports">Reports</Link></li>
              </ul>
            </li>
          )}

          {!logged ? (
            <>
              <li className="nav-item"><Link className="btn btn-outline-dark" to="/login">Login</Link></li>
              <li className="nav-item"><Link className="btn btn-primary" to="/register">Sign up</Link></li>
            </>
          ) : (
            <li className="nav-item">
              <button className="btn btn-primary" onClick={()=>setLogoutAsk(true)}>Logout</button>
            </li>
          )}
        </ul>
      </nav>

      <ConfirmDialog
        show={logoutAsk}
        title="Logout"
        message="Are you sure you want to logout?"
        confirmText="Logout"
        onCancel={()=>setLogoutAsk(false)}
        onConfirm={doLogout}
      />
    </header>
  );
}
