import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import SearchTrips from "./pages/SearchTrips";
import SeatSelection from "./pages/SeatSelection";
import Checkout from "./pages/Checkout";
import Ticket from "./pages/Ticket";
import MyBookings from "./pages/MyBookings";
import Offers from "./pages/Offers";
import Support from "./pages/Support";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AdminRoutes from "./pages/AdminRoutes";
import AdminTrips from "./pages/AdminTrips";
import AdminBuses from "./pages/AdminBuses";
import AdminOperators from "./pages/AdminOperators";
import AdminCoupons from "./pages/AdminCoupons";
import AdminReports from "./pages/AdminReports";
import ProtectedRoute from "./components/ProtectedRoute";

export default function App(){
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/search" element={<SearchTrips />} />
        <Route path="/trips/:tripId/seats" element={<SeatSelection />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/ticket/:id" element={<Ticket />} />
        <Route path="/bookings" element={<MyBookings />} />
        <Route path="/offers" element={<Offers />} />
        <Route path="/support" element={<Support />} />

        <Route path="/admin/routes" element={<ProtectedRoute requireAdmin><AdminRoutes /></ProtectedRoute>} />
        <Route path="/admin/trips" element={<ProtectedRoute requireAdmin><AdminTrips /></ProtectedRoute>} />
        <Route path="/admin/buses" element={<ProtectedRoute requireAdmin><AdminBuses /></ProtectedRoute>} />
        <Route path="/admin/operators" element={<ProtectedRoute requireAdmin><AdminOperators /></ProtectedRoute>} />
        <Route path="/admin/coupons" element={<ProtectedRoute requireAdmin><AdminCoupons /></ProtectedRoute>} />
        <Route path="/admin/reports" element={<ProtectedRoute requireAdmin><AdminReports /></ProtectedRoute>} />
      </Routes>
    </BrowserRouter>
  );
}
