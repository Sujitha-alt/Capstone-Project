import React from "react";

export default function Offers(){
  return (
    <div className="container py-3">
      <h4>Offers & Promocodes</h4>
      <div className="row g-3 mt-1">
        <div className="col-md-6">
          <div className="card p-3">
            <h6>WELCOME50</h6>
            <div className="text-muted">Flat ₹50 off on your first bus booking</div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="card p-3">
            <h6>WEEKEND10</h6>
            <div className="text-muted">10% off on Saturday-Sunday departures</div>
          </div>
        </div>
      </div>
    </div>
  );
}
