import React, { useEffect, useState } from "react";
import api from "../services/api";
import ConfirmDialog from "../components/ConfirmDialog";

export default function AdminBuses(){
  const [rows,setRows]=useState([]);
  const [form,setForm]=useState({busNumber:"",busType:"",totalSeats:"",operatorName:""});
  const [toDelete,setToDelete]=useState(null);

  const load = async()=>{ try{ const r=await api.get("/buses"); setRows(r.data||[]);}catch{} };
  useEffect(()=>{ load(); },[]);

  const submit = async(e)=>{ e.preventDefault(); await api.post("/buses", form); setForm({busNumber:"",busType:"",totalSeats:"",operatorName:""}); load(); };
  const askDelete = (id)=> setToDelete(id);
  const doDelete = async()=>{ const id=toDelete; setToDelete(null); try{ await api.delete(`/buses/${id}`); load(); }catch{ alert("Delete failed."); } };

  return (
    <div className="container py-3">
      <h4>Admin • Buses</h4>
      <div className="row g-3">
        <div className="col-md-5">
          <div className="card p-3">
            <h6>Add bus</h6>
            <form onSubmit={submit} className="vstack gap-2">
              <input className="form-control" placeholder="Bus number" value={form.busNumber} onChange={e=>setForm({...form,busNumber:e.target.value})}/>
              <input className="form-control" placeholder="Bus type" value={form.busType} onChange={e=>setForm({...form,busType:e.target.value})}/>
              <input className="form-control" placeholder="Total seats" value={form.totalSeats} onChange={e=>setForm({...form,totalSeats:e.target.value})}/>
              <input className="form-control" placeholder="Operator name" value={form.operatorName} onChange={e=>setForm({...form,operatorName:e.target.value})}/>
              <button className="btn btn-primary">Save</button>
            </form>
          </div>
        </div>
        <div className="col-md-7">
          <div className="card p-3">
            <h6>Existing</h6>
            <div className="table-responsive">
              <table className="table table-striped align-middle">
                <thead><tr><th>ID</th><th>Number</th><th>Type</th><th>Seats</th><th>Operator</th><th></th></tr></thead>
                <tbody>{rows.map(b=>(
                  <tr key={b.id}><td>{b.id}</td><td>{b.busNumber}</td><td>{b.busType}</td><td>{b.totalSeats}</td><td>{b.operatorName}</td>
                  <td className="text-end"><button className="btn btn-outline-danger btn-sm" onClick={()=>askDelete(b.id)}>Delete</button></td></tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <ConfirmDialog
        show={!!toDelete}
        title="Delete bus"
        message="Are you sure you want to delete this bus?"
        confirmText="Yes, delete"
        onCancel={()=>setToDelete(null)}
        onConfirm={doDelete}
      />
    </div>
  );
}
