import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import api from "../services/api";
import ConfirmDialog from "../components/ConfirmDialog";

export default function Checkout(){
  const { state } = useLocation();
  const navigate = useNavigate();
  const [mode, setMode] = useState("UPI");
  const [processing, setProcessing] = useState(false);
  const [ask, setAsk] = useState(false);

  if(!state) return <div className="container py-3">Missing checkout data.</div>;
  const { tripId, seats, price } = state;
  const total = (seats?.length || 0) * (price || 0);

  const pay = async () => {
    setProcessing(true);
    try{
      const booking = await api.post("/bookings", { tripId, seats });
      const bookingId = booking.data?.id;
      await api.post("/payments", { bookingId, amount: total, mode, status: "SUCCESS" });
      navigate(`/ticket/${bookingId}`);
    }catch(err){
      alert("Payment/booking failed. Try again.");
    }finally{
      setProcessing(false);
    }
  };

  return (
    <div className="container py-3">
      <h4 className="mb-3">Checkout</h4>
      <div className="card p-3">
        <div className="row g-3">
          <div className="col-md-6">
            <h6>Summary</h6>
            <div className="small text-muted">Trip: {tripId}</div>
            <div className="small text-muted">Seats: {seats?.join(", ")}</div>
            <div className="small text-muted">Price per seat: ₹ {price}</div>
            <div className="mt-2"><strong>Total: ₹ {total}</strong></div>
          </div>
          <div className="col-md-6">
            <h6>Payment mode</h6>
            <select className="form-select" value={mode} onChange={e=>setMode(e.target.value)}>
              <option>UPI</option>
              <option>CARD</option>
              <option>NETBANKING</option>
            </select>
          </div>
        </div>
        <div className="d-flex justify-content-end gap-2 mt-3">
          <button className="btn btn-outline-secondary" onClick={()=>navigate(-1)}>Back</button>
          <button className="btn btn-primary" disabled={!seats?.length || processing} onClick={()=>setAsk(true)}>
            {processing ? "Processing..." : "Pay & Book"}
          </button>
        </div>
      </div>

      <ConfirmDialog
        show={ask}
        title="Confirm payment"
        message={`Pay ₹ ${total} via ${mode}?`}
        confirmText="Confirm payment"
        onCancel={()=>setAsk(false)}
        onConfirm={()=>{ setAsk(false); pay(); }}
      />
    </div>
  );
}
