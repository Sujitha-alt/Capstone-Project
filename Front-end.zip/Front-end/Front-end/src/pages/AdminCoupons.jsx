import React, { useEffect, useState } from "react";
import api from "../services/api";
import ConfirmDialog from "../components/ConfirmDialog";

export default function AdminCoupons(){
  const [rows,setRows]=useState([]);
  const [form,setForm]=useState({code:"",discount:""});
  const [toDelete,setToDelete]=useState(null);
  const load = async()=>{ try{ const r=await api.get("/coupons"); setRows(r.data||[]);}catch{} };
  useEffect(()=>{ load(); },[]);

  const submit = async(e)=>{ e.preventDefault(); await api.post("/coupons", form); setForm({code:"",discount:""}); load(); };
  const askDelete = (id)=> setToDelete(id);
  const doDelete = async()=>{ const id=toDelete; setToDelete(null); try{ await api.delete(`/coupons/${id}`); load(); }catch{ alert("Delete failed."); } };

  return (
    <div className="container py-3">
      <h4>Admin • Coupons</h4>
      <div className="row g-3">
        <div className="col-md-5">
          <div className="card p-3">
            <h6>Add coupon</h6>
            <form onSubmit={submit} className="vstack gap-2">
              <input className="form-control" placeholder="Code" value={form.code} onChange={e=>setForm({...form,code:e.target.value})}/>
              <input className="form-control" placeholder="Discount (%)" value={form.discount} onChange={e=>setForm({...form,discount:e.target.value})}/>
              <button className="btn btn-primary">Save</button>
            </form>
          </div>
        </div>
        <div className="col-md-7">
          <div className="card p-3">
            <h6>Existing</h6>
            <div className="table-responsive">
              <table className="table table-striped align-middle">
                <thead><tr><th>ID</th><th>Code</th><th>Discount</th><th></th></tr></thead>
                <tbody>{rows.map(c=>(
                  <tr key={c.id}><td>{c.id}</td><td>{c.code}</td><td>{c.discount}%</td>
                    <td className="text-end"><button className="btn btn-outline-danger btn-sm" onClick={()=>askDelete(c.id)}>Delete</button></td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <ConfirmDialog
        show={!!toDelete}
        title="Delete coupon"
        message="Are you sure you want to delete this coupon?"
        confirmText="Yes, delete"
        onCancel={()=>setToDelete(null)}
        onConfirm={doDelete}
      />
    </div>
  );
}
