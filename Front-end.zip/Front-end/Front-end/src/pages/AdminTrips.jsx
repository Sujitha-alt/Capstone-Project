import React, { useEffect, useState } from "react";
import api from "../services/api";
import ConfirmDialog from "../components/ConfirmDialog";

export default function AdminTrips(){
  const [rows,setRows]=useState([]);
  const [form,setForm]=useState({routeId:"",busId:"",date:"",departureTime:"",price:""});
  const [toDelete,setToDelete]=useState(null);

  const load = async()=>{ try{ const r=await api.get("/trips"); setRows(r.data||[]);}catch{} };
  useEffect(()=>{ load(); },[]);

  const submit = async(e)=>{ e.preventDefault(); await api.post("/trips", form); setForm({routeId:"",busId:"",date:"",departureTime:"",price:""}); load(); };
  const askDelete = (id)=> setToDelete(id);
  const doDelete = async()=>{ const id=toDelete; setToDelete(null); try{ await api.delete(`/trips/${id}`); load(); }catch{ alert("Delete failed."); } };

  return (
    <div className="container py-3">
      <h4>Admin • Trips</h4>
      <div className="row g-3">
        <div className="col-md-5">
          <div className="card p-3">
            <h6>Add trip</h6>
            <form onSubmit={submit} className="vstack gap-2">
              <input className="form-control" placeholder="Route ID" value={form.routeId} onChange={e=>setForm({...form,routeId:e.target.value})}/>
              <input className="form-control" placeholder="Bus ID" value={form.busId} onChange={e=>setForm({...form,busId:e.target.value})}/>
              <input className="form-control" type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/>
              <input className="form-control" placeholder="Departure time (HH:mm)" value={form.departureTime} onChange={e=>setForm({...form,departureTime:e.target.value})}/>
              <input className="form-control" placeholder="Price" value={form.price} onChange={e=>setForm({...form,price:e.target.value})}/>
              <button className="btn btn-primary">Save</button>
            </form>
          </div>
        </div>
        <div className="col-md-7">
          <div className="card p-3">
            <h6>Existing</h6>
            <div className="table-responsive">
              <table className="table table-striped align-middle">
                <thead><tr><th>ID</th><th>Route</th><th>Bus</th><th>Date</th><th>Time</th><th>Price</th><th></th></tr></thead>
                <tbody>{rows.map(t=>(
                  <tr key={t.id}><td>{t.id}</td><td>{t.route?.id}</td><td>{t.bus?.id}</td><td>{t.date}</td><td>{t.departureTime}</td><td>{t.price}</td>
                    <td className="text-end"><button className="btn btn-outline-danger btn-sm" onClick={()=>askDelete(t.id)}>Delete</button></td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <ConfirmDialog
        show={!!toDelete}
        title="Delete trip"
        message="Are you sure you want to delete this trip?"
        confirmText="Yes, delete"
        onCancel={()=>setToDelete(null)}
        onConfirm={doDelete}
      />
    </div>
  );
}
