import React from "react";

export default function Support(){
  return (
    <div className="container py-3">
      <h4>Help & Support</h4>
      <div className="card p-3">
        <p className="mb-1"><strong>FAQ:</strong> Ticket, cancellation, refund timelines.</p>
        <p className="mb-0">Contact: support@sujitha.example • 9am–9pm IST.</p>
      </div>
    </div>
  );
}
