import React, { useState } from "react";
import api from "../services/api";
import { useNavigate } from "react-router-dom";

export default function SearchTrips(){
  const [source, setSource] = useState("");
  const [destination, setDestination] = useState("");
  const [date, setDate] = useState("");
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const search = async (e)=>{
    e?.preventDefault();
    setLoading(true); setError("");
    try{
      const formattedDate = date ? new Date(date).toISOString().split("T")[0] : "";
      const res = await api.get("/trips/search", { params:{ source, destination, date: formattedDate } });
      setTrips(Array.isArray(res.data) ? res.data : []);
    }catch(err){ setError("Could not load trips. Try different filters."); }
    finally{ setLoading(false); }
  };

  const select = (tripId)=> navigate(`/trips/${tripId}/seats`);

  return (
    <div className="container py-3">
      <div className="card p-3 mb-3">
        <form onSubmit={search} className="row g-3 align-items-end">
          <div className="col-md-4"><label className="form-label">From</label><input className="form-control" value={source} onChange={e=>setSource(e.target.value)} placeholder="Bengaluru" /></div>
          <div className="col-md-4"><label className="form-label">To</label><input className="form-control" value={destination} onChange={e=>setDestination(e.target.value)} placeholder="Hyderabad" /></div>
          <div className="col-md-3"><label className="form-label">Date</label><input type="date" className="form-control" value={date} onChange={e=>setDate(e.target.value)} /></div>
          <div className="col-md-1 d-grid"><button className="btn btn-primary">{loading?"...":"Search"}</button></div>
        </form>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      <div className="row g-3">
        <aside className="col-md-3">
          <div className="card p-3">
            <h6 className="mb-3">Filters</h6>
            <div className="mb-2">
              <label className="form-label">Bus type</label>
              <select className="form-select">
                <option>Any</option><option>AC</option><option>Non-AC</option><option>Sleeper</option><option>Seater</option>
              </select>
            </div>
            <div className="mb-2">
              <label className="form-label">Departure after</label>
              <input type="time" className="form-control" />
            </div>
            <div className="mb-2">
              <label className="form-label">Price range</label>
              <input type="range" className="form-range" />
            </div>
          </div>
        </aside>

        <main className="col-md-9">
          {trips.map(t => (
            <div className="d-flex gap-3 align-items-center card p-3" key={t.id}>
              <div className="flex-grow-1">
                <div className="d-flex align-items-center justify-content-between">
                  <div className="fw-bold">{t.bus?.operatorName || "Operator"}</div>
                  <span className="badge-soft">₹ {t.price}</span>
                </div>
                <div className="text-muted">{t.route?.source} → {t.route?.destination} • {t.date} • {t.departureTime}</div>
                <div className="small text-muted">Type: {t.bus?.busType || "—"} • Seats: {t.bus?.totalSeats ?? "—"}</div>
              </div>
              <div className="trip-cta d-flex align-items-center">
                <button className="btn btn-primary" onClick={()=>select(t.id)}>View Seats</button>
              </div>
            </div>
          ))}
          {(!trips || trips.length===0) && <div className="text-muted">No trips yet. Try searching.</div>}
        </main>
      </div>
    </div>
  );
}
