import React, { useState } from "react";
import api from "../services/api";
import { useNavigate, Link } from "react-router-dom";

export default function Login(){
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true); setError("");
    try{
      const res = await api.post("/auth/login", { email, password });
      if (res.data?.accessToken) localStorage.setItem("token", res.data.accessToken);
      if (res.data?.user?.role) localStorage.setItem("role", res.data.user.role);
      navigate("/search");
    }catch(err){
      setError("Login failed. Check your credentials.");
    }finally{
      setLoading(false);
    }
  };

  return (
    <div className="container py-4">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card p-3">
            <h4 className="mb-3">Login</h4>
            <form onSubmit={submit} className="vstack gap-2">
              <input className="form-control" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
              <input type="password" className="form-control" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
              {error && <div className="alert alert-danger">{error}</div>}
              <button className="btn btn-primary" disabled={loading}>{loading ? "..." : "Login"}</button>
            </form>
            <div className="mt-2 small">New user? <Link to="/register">Create an account</Link></div>
          </div>
        </div>
      </div>
    </div>
  );
}
