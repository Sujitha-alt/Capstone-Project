import React, { useState } from "react";
import api from "../services/api";
import { useNavigate, Link } from "react-router-dom";

export default function Register(){
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true); setError("");
    try{
      await api.post("/auth/register", { email, password, name });
      navigate("/login");
    }catch(err){
      setError("Registration failed. Try a different email.");
    }finally{
      setLoading(false);
    }
  };

  return (
    <div className="container py-4">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card p-3">
            <h4 className="mb-3">Create account</h4>
            <form onSubmit={submit} className="vstack gap-2">
              <input className="form-control" placeholder="Full name" value={name} onChange={e=>setName(e.target.value)} />
              <input className="form-control" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
              <input type="password" className="form-control" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
              {error && <div className="alert alert-danger">{error}</div>}
              <button className="btn btn-primary" disabled={loading}>{loading ? "..." : "Register"}</button>
            </form>
            <div className="mt-2 small">Already have an account? <Link to="/login">Login</Link></div>
          </div>
        </div>
      </div>
    </div>
  );
}
