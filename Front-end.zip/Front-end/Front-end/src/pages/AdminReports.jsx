import React, { useEffect, useState } from "react";
import api from "../services/api";

export default function AdminReports(){
  const [bookings,setBookings]=useState([]);
  const [payments,setPayments]=useState([]);
  useEffect(()=>{ (async()=>{
    try{ const b=await api.get("/reports/bookings"); setBookings(b.data||[]);}catch{}
    try{ const p=await api.get("/reports/payments"); setPayments(p.data||[]);}catch{}
  })(); },[]);

  const download = async (type)=>{
    const url = type==="bookings" ? "/reports/bookings/pdf" : "/reports/payments/pdf";
    const res = await api.get(url, { responseType:"blob" });
    const blob = new Blob([res.data], { type:"application/pdf" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${type}-report.pdf`; a.click();
  };

  return (
    <div className="container py-3">
      <h4>Admin • Reports</h4>
      <div className="row g-3">
        <div className="col-md-6">
          <div className="card p-3">
            <div className="d-flex align-items-center justify-content-between">
              <h6>Bookings</h6>
              <button className="btn btn-primary" onClick={()=>download("bookings")}>Download PDF</button>
            </div>
            <div className="table-responsive">
              <table className="table table-striped align-middle">
                <thead><tr><th>ID</th><th>User</th><th>Trip</th><th>Seats</th><th>Status</th></tr></thead>
                <tbody>{bookings.map(b=>(<tr key={b.id}><td>{b.id}</td><td>{b.username}</td><td>{b.tripId}</td><td>{Array.isArray(b.seats)?b.seats.join(", "):b.seats}</td><td>{b.status}</td></tr>))}</tbody>
              </table>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="card p-3">
            <div className="d-flex align-items-center justify-content-between">
              <h6>Payments</h6>
              <button className="btn btn-primary" onClick={()=>download("payments")}>Download PDF</button>
            </div>
            <div className="table-responsive">
              <table className="table table-striped align-middle">
                <thead><tr><th>ID</th><th>Booking</th><th>Amount</th><th>Mode</th><th>Status</th></tr></thead>
                <tbody>{payments.map(p=>(<tr key={p.id}><td>{p.id}</td><td>{p.bookingId}</td><td>₹ {p.amount}</td><td>{p.mode}</td><td>{p.status}</td></tr>))}</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
