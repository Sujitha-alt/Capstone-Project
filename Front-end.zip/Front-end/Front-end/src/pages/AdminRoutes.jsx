import React, { useEffect, useState } from "react";
import api from "../services/api";
import ConfirmDialog from "../components/ConfirmDialog";

export default function AdminRoutes(){
  const [rows,setRows]=useState([]);
  const [form,setForm]=useState({source:"",destination:"",distanceKm:""});
  const [toDelete,setToDelete]=useState(null);
  const load = async()=>{ try{ const r=await api.get("/routes"); setRows(r.data||[]);}catch{} };
  useEffect(()=>{ load(); },[]);

  const submit = async(e)=>{ e.preventDefault(); await api.post("/routes", form); setForm({source:"",destination:"",distanceKm:""}); load(); };
  const askDelete = (id)=> setToDelete(id);
  const doDelete = async()=>{ const id=toDelete; setToDelete(null); try{ await api.delete(`/routes/${id}`); load(); }catch{ alert("Delete failed."); } };

  return (
    <div className="container py-3">
      <h4>Admin • Routes</h4>
      <div className="row g-3">
        <div className="col-md-5">
          <div className="card p-3">
            <h6>Add route</h6>
            <form onSubmit={submit} className="vstack gap-2">
              <input className="form-control" placeholder="Source" value={form.source} onChange={e=>setForm({...form,source:e.target.value})}/>
              <input className="form-control" placeholder="Destination" value={form.destination} onChange={e=>setForm({...form,destination:e.target.value})}/>
              <input className="form-control" placeholder="Distance (km)" value={form.distanceKm} onChange={e=>setForm({...form,distanceKm:e.target.value})}/>
              <button className="btn btn-primary">Save</button>
            </form>
          </div>
        </div>
        <div className="col-md-7">
          <div className="card p-3">
            <h6>Existing</h6>
            <div className="table-responsive">
              <table className="table table-striped align-middle">
                <thead><tr><th>ID</th><th>Source</th><th>Destination</th><th>Distance</th><th></th></tr></thead>
                <tbody>{rows.map(r=>(
                  <tr key={r.id}><td>{r.id}</td><td>{r.source}</td><td>{r.destination}</td><td>{r.distanceKm}</td>
                    <td className="text-end">
                      <button className="btn btn-outline-danger btn-sm" onClick={()=>askDelete(r.id)}>Delete</button>
                    </td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <ConfirmDialog
        show={!!toDelete}
        title="Delete route"
        message="Are you sure you want to delete this route?"
        confirmText="Yes, delete"
        onCancel={()=>setToDelete(null)}
        onConfirm={doDelete}
      />
    </div>
  );
}
