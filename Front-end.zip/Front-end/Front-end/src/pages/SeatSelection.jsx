import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../services/api";
import ConfirmDialog from "../components/ConfirmDialog";

export default function SeatSelection(){
  const { tripId } = useParams();
  const navigate = useNavigate();
  const [layout, setLayout] = useState({ rows: 8, cols: 4, booked: [] });
  const [price, setPrice] = useState(0);
  const [selected, setSelected] = useState([]);
  const [ask, setAsk] = useState(false);

  useEffect(()=>{
    (async ()=>{
      try{
        const res = await api.get(`/trips/${tripId}`);
        setPrice(res.data?.price || 0);
        setLayout(prev => ({...prev, booked: res.data?.bookedSeats || []}));
      }catch{}
    })();
  },[tripId]);

  const toggle = (r,c)=>{
    const code = `${r}-${c}`;
    if(layout.booked.includes(code)) return;
    setSelected(prev => prev.includes(code) ? prev.filter(x=>x!==code) : [...prev, code]);
  };

  const proceed = () => {
    if(!selected.length) return;
    setAsk(true);
  };

  const confirm = () => {
    setAsk(false);
    navigate("/checkout", { state:{ tripId, seats:selected, price } });
  };

  const seatCell = (r,c)=>{
    const code = `${r}-${c}`;
    const isBooked = layout.booked.includes(code);
    const isSel = selected.includes(code);
    const cls = "k " + (isBooked ? "k-booked" : isSel ? "k-selected" : "k-free");
    return <div key={code} onClick={()=>toggle(r,c)} className={cls} title={code} style={{cursor:isBooked?"not-allowed":"pointer", width:"28px", height:"28px"}} />;
  };

  return (
    <div className="container py-3">
      <h4 className="mb-3">Select seats</h4>
      <div className="card p-3 mb-3">
        <div className="d-flex gap-4">
          <div style={{display:"grid", gridTemplateColumns:"repeat(4, 28px)", gap:"8px"}}>
            {Array.from({length:layout.rows}).map((_,r)=>(
              Array.from({length:layout.cols}).map((_,c)=> seatCell(r+1,c+1))
            ))}
          </div>
          <div>
            <div className="seat-legend mb-3">
              <span className="d-flex align-items-center gap-2"><span className="k k-free"></span> Available</span>
              <span className="d-flex align-items-center gap-2"><span className="k k-selected"></span> Selected</span>
              <span className="d-flex align-items-center gap-2"><span className="k k-booked"></span> Booked</span>
            </div>
            <div className="mb-2">Selected seats: {selected.join(", ") || "None"}</div>
            <div className="mb-3">Total: ₹ {selected.length * price}</div>
            <button className="btn btn-primary" disabled={!selected.length} onClick={proceed}>Proceed to checkout</button>
          </div>
        </div>
      </div>

      <ConfirmDialog
        show={ask}
        title="Proceed to checkout"
        message={`Confirm booking ${selected.length} seat(s) for ₹ ${selected.length * price}?`}
        confirmText="Yes, continue"
        onCancel={()=>setAsk(false)}
        onConfirm={confirm}
      />
    </div>
  );
}
