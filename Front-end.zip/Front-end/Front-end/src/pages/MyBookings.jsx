import React, { useEffect, useState } from "react";
import api from "../services/api";
import ConfirmDialog from "../components/ConfirmDialog";
import { Link } from "react-router-dom";

export default function MyBookings(){
  const [items, setItems] = useState([]);
  const [toCancel, setToCancel] = useState(null);

  const load = async () => {
    try{ const res = await api.get("/bookings/my"); setItems(res.data||[]); }catch{}
  };
  useEffect(()=>{ load(); },[]);

  const askCancel = (id) => setToCancel(id);
  const doCancel = async () => {
    const id = toCancel;
    setToCancel(null);
    try{
      await api.post(`/bookings/${id}/cancel`);
      load();
    }catch{
      alert("Cancellation failed.");
    }
  };

  return (
    <div className="container py-3">
      <h4>My Trips</h4>
      <div className="vstack gap-2 mt-2">
        {items.map(b=>(
          <div className="card p-3 d-flex flex-wrap align-items-center justify-content-between" key={b.id}>
            <div>
              <div><strong>{b.source} → {b.destination}</strong> • {b.date} {b.time}</div>
              <div className="text-muted small">Seats: {Array.isArray(b.seats)?b.seats.join(", "):b.seats}</div>
            </div>
            <div className="d-flex gap-2">
              <Link className="btn btn-outline-dark" to={`/ticket/${b.id}`}>View ticket</Link>
              {b.cancellable && <button className="btn btn-primary" onClick={()=>askCancel(b.id)}>Cancel</button>}
            </div>
          </div>
        ))}
        {!items.length && <div className="text-muted">No bookings yet.</div>}
      </div>

      <ConfirmDialog
        show={!!toCancel}
        title="Cancel booking"
        message="Are you sure you want to cancel this booking?"
        confirmText="Yes, cancel"
        onCancel={()=>setToCancel(null)}
        onConfirm={doCancel}
      />
    </div>
  );
}
