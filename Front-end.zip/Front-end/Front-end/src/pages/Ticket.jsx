import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../services/api";

export default function Ticket(){
  const { id } = useParams();
  const [ticket, setTicket] = useState(null);

  useEffect(()=>{
    (async ()=>{
      try{ const res = await api.get(`/bookings/${id}`); setTicket(res.data); }catch{}
    })();
  },[id]);

  const download = async () => {
    try{
      const res = await api.get(`/tickets/${id}/pdf`, { responseType:"blob" });
      const blob = new Blob([res.data], { type:"application/pdf" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `ticket-${id}.pdf`;
      a.click();
    }catch{
      alert("Could not download ticket.");
    }
  };

  return (
    <div className="container py-3">
      <h4 className="mb-3">Your Ticket</h4>
      <div className="card p-3">
        {ticket ? (
          <>
            <div><strong>{ticket.source} → {ticket.destination}</strong></div>
            <div className="text-muted">{ticket.date} {ticket.time}</div>
            <div className="text-muted small">Seats: {Array.isArray(ticket.seats) ? ticket.seats.join(", ") : ticket.seats}</div>
            <div className="mt-3">
              <button className="btn btn-primary" onClick={download}>Download PDF</button>
            </div>
          </>
        ) : "Loading..."}
      </div>
    </div>
  );
}
