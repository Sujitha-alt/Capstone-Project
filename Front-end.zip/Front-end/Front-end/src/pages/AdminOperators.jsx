import React, { useEffect, useState } from "react";
import api from "../services/api";
import ConfirmDialog from "../components/ConfirmDialog";

export default function AdminOperators(){
  const [rows,setRows]=useState([]);
  const [form,setForm]=useState({name:"",rating:""});
  const [toDelete,setToDelete]=useState(null);
  const load = async()=>{ try{ const r=await api.get("/operators"); setRows(r.data||[]);}catch{} };
  useEffect(()=>{ load(); },[]);

  const submit = async(e)=>{ e.preventDefault(); await api.post("/operators", form); setForm({name:"",rating:""}); load(); };
  const askDelete = (id)=> setToDelete(id);
  const doDelete = async()=>{ const id=toDelete; setToDelete(null); try{ await api.delete(`/operators/${id}`); load(); }catch{ alert("Delete failed."); } };

  return (
    <div className="container py-3">
      <h4>Admin • Operators</h4>
      <div className="row g-3">
        <div className="col-md-5">
          <div className="card p-3">
            <h6>Add operator</h6>
            <form onSubmit={submit} className="vstack gap-2">
              <input className="form-control" placeholder="Name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
              <input className="form-control" placeholder="Rating (0-5)" value={form.rating} onChange={e=>setForm({...form,rating:e.target.value})}/>
              <button className="btn btn-primary">Save</button>
            </form>
          </div>
        </div>
        <div className="col-md-7">
          <div className="card p-3">
            <h6>Existing</h6>
            <div className="table-responsive">
              <table className="table table-striped align-middle">
                <thead><tr><th>ID</th><th>Name</th><th>Rating</th><th></th></tr></thead>
                <tbody>{rows.map(o=>(
                  <tr key={o.id}><td>{o.id}</td><td>{o.name}</td><td>{o.rating}</td>
                    <td className="text-end"><button className="btn btn-outline-danger btn-sm" onClick={()=>askDelete(o.id)}>Delete</button></td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <ConfirmDialog
        show={!!toDelete}
        title="Delete operator"
        message="Are you sure you want to delete this operator?"
        confirmText="Yes, delete"
        onCancel={()=>setToDelete(null)}
        onConfirm={doDelete}
      />
    </div>
  );
}
