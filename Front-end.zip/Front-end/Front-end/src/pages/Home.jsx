import React from "react";
import { Link } from "react-router-dom";

export default function Home(){
  return (
    <div className="container py-4">
      <div className="hero">
        <div className="hero-banner">
          <h1>Book bus tickets across India</h1>
          <p>Search routes, view seat maps, apply offers, and travel stress-free.</p>
        </div>
      </div>
      <div className="d-flex gap-2">
        <Link className="btn btn-primary" to="/search">Search Buses</Link>
        <Link className="btn btn-outline-dark" to="/offers">View Offers</Link>
      </div>
    </div>
  );
}
